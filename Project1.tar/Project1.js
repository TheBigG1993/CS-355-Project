// Module dependencies

var express    = require('express'),
    mysql      = require('mysql');

// Application initialization

var connection = mysql.createConnection({
    host     : 'cwolf.cs.sonoma.edu',
    user     : 'gchobotov',
    password : '3918491'
});

var app = module.exports = express.createServer();

// Database setup

connection.query('USE gchobotov', function (err) {
    if (err) throw err;
});

// Configuration

app.use(express.bodyParser());

// Main page to view the Warriors table, Warrior players table, LA Lakers table, and the LA Lakers players table.

var htmlHeader = '<html><head><title>University Database</title></head><body>';
var htmlFooter = '</body></html>';

function handleError(res, error) {
    console.log(error);
    res.send(error.toString());
}
function buildUserView(result) {

    // Build the HTML table from the data in the Players table
    var responseHTML = htmlHeader + '<h1>PlayerInformation</h1>';

    //Dynamic populating rows from the records returned
    for (var i=0; i < result.length; i++) {
        responseHTML +=
	    '<li>Player name: ' + result[i].Player_name + '</li>' +
            '<li>Points scored: ' + result[i].Points_scored + '</li>' +
            '<li>Rebounds: ' + result[i].Rebounds + '</li>' + 
	    '<li>Assists: ' + result[i].Assists + '</li></ul>'
    }
    responseHTML += htmlFooter;

    return responseHTML;
}

app.get('/', function(req, res) {
    req.query.name
    res.send('<html><head><title>Project1</title></head><body>' +
            '<a href="/warriors_players/add">Add a GoldenStateWarriorsPlayer</a><br />' +
            '<a href="/warriors/view/table">View Warriors HTML Table</a><br />' +
	     '<a href="/warriors_players/view/table">View Warrior Players HTML Table</a><br />' +
	    '<a href="/lakers_players/add">Add a LakersPlayer</a><br />' +
            '<a href="/lakers/view/table">View Lakers HTML Table</a><br />' +  '<a href="/lakers_players/view/table">View Lakers Players HTML Table</a><br /></body></html>'
    );
});

// HTML Example with data populated from the Warriors table

app.get('/warriors/view/table', function (req, res) {

    var myQry = 'SELECT * FROM GoldenStateWarriors';

    console.log(myQry);

    connection.query(myQry,
        function (err, result) {
            if (err) {
                handleError(res, err);
            }
            else {
                // Build the HTML table from the data in the Warriors table
                var responseHTML = '<h1>GoldenStateWarriors Table</h1>';
                responseHTML += '<table border=1>' +
                    '<tr><th>Current season wins</th>' +
                    '<th>Current season loses</th>' +
                    '<th><Championships</th></tr>';
		 //Dynamic populating rows from the records returned
                for (var i=0; i < result.length; i++) {
                    responseHTML += '<tr><td>' + result[i].Current_season_wins + '</td>' +
                        '<td>' + result[i].Current_season_loses + '</td>' + '<td>' + result[i].Championships + '</td></tr>'
                }
                responseHTML += '</table>';
                res.send(responseHTML);

}
}
)
});

// HTML Example with data populated from the WarriorsPlayers table

app.get('/warriors_players/view/table', function (req, res) {

    var myQry = 'SELECT * FROM GoldenStateWarriorsPlayers';

    console.log(myQry);

    connection.query(myQry,
        function (err, result) {
            if (err) {
                handleError(res, err);
            }
            else {
                // Build the HTML table from the data in the Warriors table
                var responseHTML = '<h1>Golden State Warriors Players</h1>';
                responseHTML += '<table border=1>' +
                    '<tr><th>Player Name</th>' +
                    '<th>Player Number</th>' + '<th>Player Position</th>' +
                    '<th><!-- More Info Column --></th>' +
                    '<th><!-- Edit Info Column --></th>' +
                    '<th><!-- Delete Column --></th>' +
                    '</tr>';

                //Dynamic populating rows from the records returned
                for (var i=0; i < result.length; i++) {
                    responseHTML += '<tr><td>' + result[i].Player_name + '</td>' +
                        '<td>' + result[i].Player_number + '</td>' + '<td>' + result[i].Player_position + '</td>' +
                        '<td><a href="/warriors_players/?Player_name=' + result[i].Player_name+ 
'">more info</a>' + '<td><a href="/warriors_players/edit?Player_name=' + result[i].Player_name + '">edit</a>' + '<td><a href="/warriors_players/delete?Player_name=' + result[i].Player_name + '">delete</a>' +
                        '</tr>'
                }

                responseHTML += '</table>';
                res.send(responseHTML);
            }
        }
    );
});

// HTML Example with data populated from the Lakers table

app.get('/lakers/view/table', function (req, res) {

    var myQry = 'SELECT * FROM LA_Lakers';

    console.log(myQry);

    connection.query(myQry,
        function (err, result) {
            if (err) {
                handleError(res, err);
            }
            else {
                // Build the HTML table from the data in the Lakers table
                var responseHTML = '<h1>Los Angeles Lakers Table</h1>';
                responseHTML += '<table border=1>' +
                    '<tr><th>Current season wins</th>' +
                    '<th>Current season loses</th>' +
                    '<th><Championships</th></tr>';
                 //Dynamic populating rows from the records returned
                for (var i=0; i < result.length; i++) {
                    responseHTML += '<tr><td>' + result[i].Current_season_wins + '</td>' +
                        '<td>' + result[i].Current_season_loses + '</td>' + '<td>' + result[i]
.Championships + '</td></tr>'
                }
                responseHTML += '</table>';
                res.send(responseHTML);

}
}
)
});

// HTML Example with data populated from the LakersPlayers table

app.get('/lakers_players/view/table', function (req, res) {

    var myQry = 'SELECT * FROM LA_LakersPlayers';

    console.log(myQry);

    connection.query(myQry,
        function (err, result) {
            if (err) {
                handleError(res, err);
            }
            else {
                // Build the HTML table from the data in the Lakers table
                var responseHTML = '<h1>Los Angeles Lakers Players</h1>';
                responseHTML += '<table border=1>' +
                    '<tr><th>Player Name</th>' +
                    '<th>Player Number</th>' + '<th>Player Position</th>' +
                    '<th><!-- More Info Column --></th>' +
                    '<th><!-- Edit Info Column --></th>' +
                    '<th><!-- Delete Column --></th>' +
                    '</tr>';

                //Dynamic populating rows from the records returned
                for (var i=0; i < result.length; i++) {
                    responseHTML += '<tr><td>' + result[i].Player_name + '</td>' +
                        '<td>' + result[i].Player_number + '</td>' + '<td>' + result[i].Player_position + '</td>' +
                        '<td><a href="/lakers_players/?Player_name=' + result[i].Player_name+'">more info</a>' + '<td><a href="/lakers_players/edit?Player_name=' + result[i].Player_name + 
'">edit</a>' + '<td><a href="/lakers_players/delete?Player_name=' + result[i].Player_name + 
'">delete</a>' +
                        '</tr>'
                }

                responseHTML += '</table>';
                res.send(responseHTML);
            }
        }
    );
});

// Display information about a Warriors player when given their name.
app.get('/warriors_players/', function (req, res) {

    var myQry = 'SELECT * FROM GoldenStateWarriorsPlayerStats WHERE Player_name= '+ "'" + req.query.Player_name + "'";

    console.log(myQry);

    connection.query(myQry,
        function (err, result) {
            if (err) {
                handleError(res, err);
            }
            else {
                res.send(buildUserView(result));
            }
        }
    );
});

// Display information about a Lakers player when given their name.
app.get('/lakers_players/', function (req, res) {

    var myQry = 'SELECT * FROM LA_LakersPlayerStats WHERE Player_name= '+ "'" + req.query.Player_name + "'";

    console.log(myQry);

    connection.query(myQry,
        function (err, result) {
            if (err) {
                handleError(res, err);
            }
            else {
                res.send(buildUserView(result));
            }
        }
    );
});

// Display a form that allows user to enter Warriors Players
app.get('/warriors_players/add', function(req, res){

    var responseHTML = htmlHeader;

    responseHTML += '<h1>Insert a Player</h1>' +
        '<form action="/warriors_players/insert" method="GET">' +
        '<input type="hidden" name="Player_number" id="Player_number" />' +
        '<label for="Player_name">Player_name</label> <input type="text" name="Player_name" i="Player_name" /><br />' + '<label for="Points_scored">Points_scored<label> <input type="text"\name="Points_scored" id="Points_scored" /><br />' +  '<label for="Rebounds">Pebounds<label> <input type="text"name="Rebounds" id="Rebounds" /><br />' +  '<label for="Assists">Assists<label> <input type="text"name="Assists" id="Assists" /><br />' + '<input type="submit" />' + '</form>';

    responseHTML += htmlFooter;
    res.send(responseHTML);
});

app.get('/warriors_players/insert', function(req, res){

    var myQry = 'INSERT INTO GoldenStateWarriorsPlayerStats (Player_name, Points_scored, Rebounds, Assists) VALUES (' +
        '\'' + req.query.Player_name + '\',' +
        '\'' + req.query.Points_scored + '\,' +
	'\'' + req.query.Rebounds + '\',' +
	'\'' + req.query.Assists + '\'' +
        ')';

    console.log(myQry);

    connection.query(myQry,
        function (err, result) {
            if (err) {
                handleError(res, err);
            }
            else {
                connection.query('SELECT * FROM GoldenStateWarriorsPlayers WHERE Player_name=' + result.insertId,
                    function (err, result) {
                        if (err) {
                            handleError(res, err);
                        }
                        else if(result.length == 1) {
                            res.send(buildUserView(result));
                        }
                        else {
                            res.send('Player added.');
                        }
                    });
            }
        }
    );
});


// Display a form that allows user to enter Lakers Players
app.get('/lakers_players/add', function(req, res){

    var responseHTML = htmlHeader;

    responseHTML += '<h1>Insert a Player</h1>' +
        '<form action="/lakers_players/insert" method="GET">' +
        '<input type="hidden" name="Player_name" id="Player_name" />' +
        '<label for="Player_name">Player_name</label> <input type="text" name="Player_name" i\
="Player_name" /><br />' + '<label for="Player_number">Player_number</label> <input type="tex\
" name="Player_number" id="Player_number" /><br />' +
        '<label for="Points_scored">Points_scored</label> <input type="text" name="Points_sco\
ed" id="Points_scored" /><br />'+
        '<label for="Rebounds">Rebounds</label><br /><textarea name="Rebounds" id="Rebounds"><textarea><br />' +
        '<input type="submit" />' +
        '</form>';

    responseHTML += htmlFooter;
    res.send(responseHTML);
});

// Begin listening

app.listen(8007);
console.log("Express server listening on port %d in %s mode", app.address().port, app.settings.env);

