CREATE TABLE GoldenStateWarriors(Current_season_wins INT, Current_season_loses INT, Championships INT);
CREATE TABLE GoldenStateWarriorsPlayers(Player_name VARCHAR(50) PRIMARY KEY, Player_number INT UNIQUE KEY, Player_position VARCHAR(50));
CREATE TABLE GoldenStateWarriorsPlayerStats(Player_name VARCHAR(50),FOREIGN KEY(Player_name) REFERENCES GoldenStateWarriorsPlayers(Player_name) ON DELETE CASCADE ON UPDATE CASCADE, Points_scored INT, Rebounds INT, Assists INT);

 CREATE TABLE LA_Lakers(Current_season_wins INT, Current_season_loses INT, Championsh\
ips INT);
CREATE TABLE LA_LakersPlayers(Player_name VARCHAR(50) PRIMARY KEY, Player_number INT\UNIQUE KEY, Player_position VARCHAR(50));
CREATE TABLE LA_LakersPlayerStats(Player_name VARCHAR(50),FOREIGN KEY(Player_name) REFERENCES GoldenStateWarriorsPlayers(Player_name) ON DELETE CASCADE ON UPDATE CASCADE, Points_scored INT, Rebounds INT, Assists INT);

Warriors table
+---------------------+----------------------+---------------+
| Current_season_wins | Current_season_loses | Championships |
+---------------------+----------------------+---------------+
|                  62 |                   13 |             3 |
+---------------------+----------------------+---------------+

Warriors players table
+----------------------+---------------+-----------------+
| Player_name          | Player_number | Player_position |
+----------------------+---------------+-----------------+
| Andre Iguodala       |             9 | Gaurd-Forward   |
| Andrew Bogut         |            12 | Center          |
| Brandon Rush         |             4 | Gaurd-Forward   |
| David Lee            |            10 | Forward-Center  |
| Draymond Green       |            23 | Forward         |
| Festus Ezeli         |            31 | Center          |
| Harrison Barnes      |            40 | Forward         |
| James Michael McAdoo |            20 | Forward         |
| Justin Holiday       |             7 | Gaurd           |
| Klay Thompson        |            11 | Gaurd           |
| Leandro Barbosa      |            19 | Gaurd           |
| Marreese Speights    |             5 | Center-Forward  |
| Ognjen Kuzmic        |             1 | Center          |
| Shaun Livingston     |            34 | Gaurd           |
| Stephen Curry        |            30 | Gaurd           |
+----------------------+---------------+-----------------+

Warriors player stats table
+----------------------+---------------+----------+---------+
| Player_name          | Points_scored | Rebounds | Assists |
+----------------------+---------------+----------+---------+
| Andre Igoudala       |             7 |        1 |       1 |
| Andrew Bogut         |             6 |        8 |       3 |
| Brandon Rush         |             1 |        1 |       0 |
| Leandro Barbosa      |             7 |        1 |       1 |
| Harrison Barnes      |            10 |        5 |       1 |
| Stephen Curry        |            24 |        4 |       8 |
| Festus Ezeli         |             4 |        3 |       1 |
| Draymond Green       |            12 |        8 |       4 |
| Justin Holiday       |             4 |        1 |       1 |
| Ognjen Kuzmic        |             1 |        1 |       1 |
| David Lee            |             8 |        6 |       2 |
| Shaun Livingston     |             6 |        2 |       3 |
| James Michael McAdoo |             4 |        3 |       1 |
| Marreese Speights    |            11 |        4 |       1 |
| Klay Thompson        |            22 |        3 |       3 |
+----------------------+---------------+----------+---------+


Lakers table
+---------------------+----------------------+---------------+
| Current_season_wins | Current_season_loses | Championships |
+---------------------+----------------------+---------------+
|                  20 |                   56 |            16 |
+---------------------+----------------------+---------------+

Lakers player table
+-----------------+---------------+-----------------+
| Player_name     | Player_number | Player_position |
+-----------------+---------------+-----------------+
| Carlos Boozer   |             5 | Forward         |
| Dwight Buycks   |            20 | Gaurd           |
| Ed Davis        |            21 | Forward         |
| Jabari Brown    |            15 | Gaurd           |
| Jeremy Lin      |            17 | Gaurd           |
| Jordan Clarkson |             6 | Gaurd           |
| Jordan Hill     |            27 | Center          |
| Julius Randle   |            30 | Forward         |
| Kobe Bryant     |            24 | Gaurd           |
| Nick Young      |             0 | Forward-Gaurd   |
| Robert Sacre    |            50 | Center          |
| Ronnie Price    |             9 | Gaurd           |
| Ryan Kelly      |             4 | Forward         |
| Tarik Black     |            28 | Center-Forward  |
| Wayne Ellington |             2 | Gaurd           |
| Wesley Johnson  |            11 | Forward         |
+-----------------+---------------+-----------------+

Laker player stats table
+-----------------+---------------+----------+---------+
| Player_name     | Points_scored | Rebounds | Assists |
+-----------------+---------------+----------+---------+
| Tarik Black     |             6 |        6 |       1 |
| Carlos Boozer   |            12 |        7 |       1 |
| Jabari Brown    |             9 |        2 |       2 |
| Kobe Bryant     |            22 |        6 |       6 |
| Dwight Buycks   |             9 |        2 |       1 |
| Jordan Clarkson |            11 |        3 |       3 |
| Ed Davis        |             8 |        7 |       1 |
| Wayne Ellington |            10 |        3 |       2 |
| Jordan Hill     |            12 |        8 |       2 |
| Wesley Johnson  |            10 |        4 |       2 |
| Ryan Kelly      |             6 |        3 |       1 |
| Jeremy Lin      |            11 |        3 |       5 |
| Ronnie Price    |             5 |        2 |       4 |
| Julius Randle   |             2 |        0 |       0 |
| Robert Sacre    |             4 |        3 |       1 |
| Nick Young      |            13 |        2 |       1 |
+-----------------+---------------+----------+---------+
